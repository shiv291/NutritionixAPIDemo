﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NutritionixDemo
{
    internal class Program
    {       
        private const string myApiId = "262b5880";
        private const string myApiKey = "b6ee74382a6ba02211f2ea3edd4413c1";
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your food name ");
            string input = Console.ReadLine();
            var client = new RestClient("https://trackapi.nutritionix.com/v2/search/instant?query=2 apples");
            //client.Timeout = -1;
            var request = new RestRequest();
            request.AddHeader("x-app-id", "262b5880");
            request.AddHeader("x-app-key", "b6ee74382a6ba02211f2ea3edd4413c1");
            RestResponse response = client.GetAsync(request).Result;
            ResponseData res = JsonConvert.DeserializeObject<ResponseData>(response.Content);
            string col = string.Format("{0}\t\t{1}\t{2}\t{3}\t{4}\t{5}", "Food Name", "Quantity", "Measure", "Calories", "Protein", "Vitamin A");
            Console.WriteLine(col);
            foreach(var item in res.branded)
            {
                string row = string.Format("{0}\t\t{1}\t{2}\t{3}\t{4}\t{5}", item.food_name, item.serving_qty, item.serving_unit, item.nf_calories, "", "");
                Console.WriteLine(row);
            }

            Console.ReadLine();
        }
    }
}
