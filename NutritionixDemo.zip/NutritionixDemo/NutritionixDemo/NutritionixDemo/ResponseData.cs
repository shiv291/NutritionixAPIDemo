﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NutritionixDemo
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class Photo
    {
        public string thumb { get; set; }
        public object highres { get; set; }
        public bool? is_user_uploaded { get; set; }
    }

    public class Common
    {
        public string food_name { get; set; }
        public string serving_unit { get; set; }
        public string tag_name { get; set; }
        public decimal serving_qty { get; set; }
        public int? common_type { get; set; }
        public string tag_id { get; set; }
        public Photo photo { get; set; }
        public string locale { get; set; }
    }

    public class Branded
    {
        public string food_name { get; set; }
        public string serving_unit { get; set; }
        public string nix_brand_id { get; set; }
        public string brand_name_item_name { get; set; }
        public decimal serving_qty { get; set; }
        public decimal nf_calories { get; set; }
        public Photo photo { get; set; }
        public string brand_name { get; set; }
        public int region { get; set; }
        public decimal brand_type { get; set; }
        public string nix_item_id { get; set; }
        public string locale { get; set; }
    }

    public class ResponseData
    {
        public ResponseData()
        {
            branded = new List<Branded>();           
            common = new List<Common>();
        }
        public List<Common> common { get; set; }
        public List<Branded> branded { get; set; }
    }


}
